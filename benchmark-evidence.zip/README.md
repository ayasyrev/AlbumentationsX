# Issue #584 benchmark evidence

Open [the appendix](docs/reports/2026-10-21-albumentationsx-issue-584-benchmark-appendix.md) for the matrices, source-row IDs, methodology and reproduction entry points.

The original 120-case run and expanded 671-case run are separate datasets. No new timings were collected during packaging. NumKong findings are retained in separate report and evidence files.
