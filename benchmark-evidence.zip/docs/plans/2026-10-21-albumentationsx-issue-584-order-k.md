# #584: broader C-order / K-order investigation

The user requested broader validation of the optional K-order candidate, including
other transforms, on 2026-10-21. This authorizes local experiments and evidence;
the reviewed C-order commit remains the implementation under review.

## Decision and sources

Compare the unsafe original helper at `45a1afe21448fd2e83716733e2880c00335060fb`,
the reviewed C-order helper at `ff6db7b86e9094112a2e5a0ba2268ab4f199791f`, and
the exact latter source with only `order="C"` changed to `order="K"` in memory.
Determine whether K preserves the storage/value contract and improves complete
public workloads, including downstream layout consumers. No dependency changes,
terminal ToTensor fixes, endian changes, publication, or automatic adoption.

Use the existing worktree and its own locked environment, published Albucore
0.2.21, and the installed original baseline outside the source checkout.
Archive source hashes, all cells, sample distributions, environment and commands.

## Coverage

- Direct bridge: the 256/512/1024 × C1/C3/C5 × uint8/float16/float32 matrix,
  writable, readonly C/F, positive-strided readonly and negative-strided storage.
  Reuse the existing 452 bridge regression cases for semantic boundaries.
- Public Compose: uint8/float32 and the same size/channel matrix for RandomGamma,
  RandomBrightnessContrast (max and mean contrast), InvertImg, Solarize,
  Posterize, Equalize, GaussianBlur, HorizontalFlip, Resize and Normalize.
  Add RGBShift, HueSaturationValue and CLAHE on their supported channels.
  Record exact constructor arguments and observed bridge copy conditions.
- Batch: sizes 4/8/16 at 256×256×3; compare batch dispatch with per-image Compose
  plus stack for Gamma, brightness/contrast and GaussianBlur.
- Volumes: depth 4 at 64×64, C1/C3/C5, single and two-volume collections,
  for Gamma, brightness/contrast and GaussianBlur.
- Pipelines: Gamma followed by GaussianBlur, brightness/contrast, Normalize or
  HorizontalFlip. Include contiguous materialization, float conversion, stacking
  and CPU convolution consumers so conversion-only wins are not overgeneralized.
- Seeded NumPy Compose is the public oracle. Check C/K values, shape, dtype,
  input immutability, output strides and readonly detachment before timing.
  Inspect backend dispatch; explicitly record unsupported or baseline-defective
  combinations rather than silently omitting them.

## Method and delivery

Resource preflight before execution; one numerical thread. Rotate baseline/C/K
order in one process, warm each variant, use at least 100 calls for fast cases
and at least one second of aggregate timing for slow cases. Investigate apparent
regressions above 5% with additional alternating paired rounds. Do not benchmark
in parallel with tests or other local experiments.

The ASV catalog does not expose copy order or readonly result storage, so extend
a persistent focused harness under `_internal/` and archive it with the report.
Run semantic preflight before the full timing matrix. Run affected existing
Tensor suites under the in-memory K helper. Review the harness, timings and
claims locally; no new independent review is claimed.

Report per-transform summaries and all raw cells in separate CSV/JSON artifacts,
not another huge PR-body table. Document limitations (one Linux host, one locked
dependency set, no macOS/GPU validation) and any measured tradeoff before making
an adoption recommendation. Update the existing task record and queue links.

## Semantic preflight findings

Initial manifest: 607 cells. Equalize rejects C5 by its documented contract;
retain the six rejection observations and remove these unsupported timing cells.
Add standard Normalize alone and after Gamma (36 cells), yielding 637 supported
manifest cells. Keep the two failing NumPy-oracle comparisons separately from
performance claims; benchmark only validated cases.

The new independent float64 normalization oracle localized a pre-existing
dependency defect to NumKong 7.8.4 moments on interleaved uint8 data at
1024×1024×4/5. Sum-of-squares errors are multiples of 2**32; Albucore 0.2.21
therefore computes standard deviation 0.0001 instead of approximately 59.
In Gamma → per-channel Normalize at C5, baseline and K retain the failing
interleaved layout; C repacking incidentally bypasses the defect. This prevents
an unconditional K-order adoption recommendation with the locked dependencies.
The standalone Tensor Normalize case is identical for baseline/C/K, while the
NumPy input route is defective. No dependency or package-source fix is in scope.

Initial paired bridge timings also show substantial K-order regressions for
readonly stepped and negative-width-stride interleaved arrays. Add 36 public
Compose + Lambda cells (256/512/1024 × C1/C3/C5 × uint8/float32 × two callbacks)
to establish whether this occurs beyond isolated bridge timings. Preserve the
original full-matrix harness/hash and store this supplement separately.

## Outcome

Completed: 635 primary timing cells + 36 callback cells, all exit 0; 250
investigations with 12 extra alternating rounds. Five apparent >5% improvements
in no-copy float32 controls were rerun with longer blocks and disappeared
(−0.18…+0.40%). Existing K-injected tests: 576 + 1,526 passed, exit 0.
The supported semantic manifest retains its two documented dependency-related
discrepancies (637 cases, exit 1); they are not counted as performance wins.

Universal K-order is rejected for this fix: 79 measured K/C regressions >5%,
including actual public callbacks and per-image + stack, plus the dependent
Normalize defect. 115 timing cells improve >5%; none of this supports adopting
K globally. The C-order commit remains unchanged and no PR was published.

Final report: `docs/reports/2026-10-21-albumentationsx-issue-584-order-k.md`.
All 671 cells, raw rounds and runnable harnesses are saved alongside that report.
