# #584: copy incompatible NumPy storage before Tensor fallback

## Source and acceptance

Simple implementation route. The user explicitly requested preparation of the
specific minimal fix supplied in this conversation on 2026-10-21. This is the
scope and plan acceptance; formal task/plan reviews are not applicable.

Authoritative source: https://github.com/albumentations-team/AlbumentationsX/issues/584
(OPEN, updated 2026-10-15, no comments, checked live on 2026-10-21).
The issue requires copying readonly NumPy results before `torch.from_numpy`
and preserving zero-copy for compatible writable nonnegative strides.
The proposed two-line candidate has no published branch or PR. The complete
open-PR list was checked; #588 is adjacent dependency/half work, not this fix.

Repository: AlbumentationsX only. Base: freshly fetched `upstream/main`,
`45a1afe21448fd2e83716733e2880c00335060fb`.
Worktree: `/home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor`.
Branch: `aya/issue-584-readonly-tensor`.
The user's explicit `worktree/` location overrides the CLI's hard-coded
`worktrees/<repo>/` location; create with Git and attach/prepare with the CLI.
No unrelated checkout or WIP is transferred.

## Contract and scope

- Update existing `core.tensor._numpy_to_tensor` after the existing axis
  conversion: copy with `np.array(value, copy=True, order="C")` if readonly or
  any stride is negative; otherwise wrap the original storage.
- The output retains values, dtype, shape and canonical channel-first axes.
  Copied results own writable storage and safe Tensor writes cannot affect the
  readonly source. Compatible writable C/F/positive/zero-strided views keep
  sharing memory. Masks are not clipped and annotations still become float32.
- Cover all eight spatial target families and both annotation wrappers;
  supported native image helper uint8/float16/float32 and mask int16 values.
  Compose input dtype validation remains uint8/float32 for image Tensors.
- Include readonly bytes, readonly strided/broadcast views, writable controls,
  negative strides, C-contiguous singleton negative strides and empty arrays.
  Independent NumPy transposes and exact expected values are the oracles.
- Exercise actual fallback through Compose (RandomGamma, including aliases,
  images/volume/volumes as applicable) and annotation restoration. Check warning
  capture explicitly, since suite defaults ignore UserWarning. Never write to
  a baseline Tensor until independence from readonly storage is established.
- No changes to terminal ToTensorV2/3D, byte-order handling (#595), dependency
  pin, Core API, input validation, RNG, replay, dispatch, or root copying.
  Shared Core bridge API consolidation remains a separate follow-up.

## Implementation and validation

1. Prepare a worktree-owned environment from the unchanged lock, with published
   Albucore and CPU Torch. Record package versions/import paths and inspect host
   CPU/memory load before executable validation.
2. Add permanent regressions. Run the new tests on the unmodified helper to
   record failures and controls before changing runtime code.
3. Apply the two-line fix, rerun focused regressions, then the affected Tensor
   routing/annotation/Compose suites. Run the required pre-commit quality gate.
4. Measure paired baseline/candidate in the same environment with one numerical
   thread, warmups and at least 100 calls per fast cell. Image matrix:
   256/512/1024 x C1/C3/C5 x uint8/float32. Measure direct bridge writable and
   readonly storage, plus Compose RandomGamma Tensor conversion. Add bounded
   batch/volume cells to expose copying costs without changing dispatch.
   Preserve every cell and investigate >5% regressions with alternating paired
   reruns; the readonly copy is an intentional safety cost, not a speedup claim.
   Use an installed baseline outside source checkout and verify import paths.
   If ASV cannot express the storage modes, keep the focused harness in
   `_internal/` and archive it with the shared report evidence.
5. Review exact diff for correctness/ownership, performance, delivery and live
   base freshness. Record checks and limitations, update affected queue status,
   and make a local preparation commit. No GitHub publication is requested.

## Risks and evidence boundaries

Readonly outputs necessarily allocate once; suitable writable outputs must
remain zero-copy. `ascontiguousarray` and `np.require(C,W)` can leave negative
strides on singleton axes, so forced copying is essential. A C-copy preserves
foreign endian, which remains outside this fix. Baseline main may have known
failures addressed by #588; distinguish these rather than incorporating that PR.
Sandbox DataLoader IPC can hang on resource-sharer `setsockopt`; only rerun
affected multiprocessing checks outside the sandbox if they are required.

Completion report:
`docs/reports/2026-10-21-albumentationsx-issue-584-readonly-tensor.md`.

## Execution outcome

Implemented and locally committed as `ff6db7b86e9094112a2e5a0ba2268ab4f199791f`.
The actual lockfile uses published Albucore 0.2.21; no dependency changes were
needed. Environment: worktree-owned Python 3.13.14. Corrected red baseline:
201 failed / 259 passed; candidate focused/adjacent suites: 576 + 1526 passed.
Final all-files pre-commit and commit hooks exited 0.

Benchmark manifest expanded only to include required float16 direct-bridge
diagnostics; the public Compose matrix remains uint8/float32. All 120 paired
cells and 53 >5% investigations are recorded in the report. Writable bridge
overhead stays below 5%; readonly copies intentionally add work, with the
largest measured uint8 Compose increase of 26.69%. No optimization claim is made.
No full suite, hosted CI, independent implementation review, or publication ran
during implementation. Subsequently the user supplied an independent review of
the exact commit with no blocking correctness or contract findings; recorded in
`docs/reports/2026-10-21-albumentationsx-issue-584-review-handoff.md`.
The reported K-order comparison is optional preliminary evidence, not an adopted
change. A local PR description was prepared; publication has not occurred.

The subsequent user-requested [broader K-order investigation](2026-10-21-albumentationsx-issue-584-order-k.md)
is complete: 671 timing cells, existing 2,102 tests under K, and preserved
normalization dependency findings. Universal K was rejected; this C-order
implementation and its accepted scope remain unchanged.
