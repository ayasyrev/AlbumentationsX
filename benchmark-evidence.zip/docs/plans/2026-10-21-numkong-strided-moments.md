# NumKong: attribution of strided uint8 moments failure

User request: explain whether the normalization discrepancy found during AX #584
C/K validation belongs to NumKong or its caller, clarify the excluded timing
cells, and prepare an upstream issue if appropriate.

Scope: investigation and a local issue draft; no dependency upgrades in the
reviewed AX environment and no runtime changes to AX/Albucore.

1. Read NumKong's public reduction/stride/output contract and the exact source
   for installed 7.8.4; check current release/main and existing issues/PRs.
2. Reduce the failure to NumPy + NumKong only, with an independent uint64 or
   Python-integer oracle. Capture versions, CPU/capabilities and import paths.
3. Bound the failure by length, values, stride, rank and available dispatch
   modes. Check relevant boundary/first-beyond and contiguous controls.
4. Verify current upstream behavior in an isolated environment if versions
   differ; distinguish executed evidence from source inference.
5. Trace both excluded #584 cells and audit that they were excluded before
   timing, while preserving the original raw evidence.
6. Save source findings, reproducible evidence, report and an English issue
   draft if the supported NumKong API fails. Update coordination status.

Acceptance: attribution backed by a standalone reproducer and public contract;
explicit account of the two excluded cells and implications for reported
timings; upstream issue draft ready for review without unsupported root-cause
or platform claims. Published issue and upstream patch are outside this step.

Validation is correctness-only; no new performance claims. Resource preflight
before scripts/builds. Risks: installed wheel/source mismatch, SIMD-specific
behavior, latest-version drift, existing upstream fix or duplicate issue.

Completed: [report](../reports/2026-10-21-numkong-strided-moments.md) and
[upstream issue draft](../reports/2026-10-21-numkong-strided-moments-issue.md).
NumKong 7.8.4 and 7.8.5 produce identical failures without downstream imports;
the supported API and overflowing AVX2 arithmetic are confirmed in source.
Scope added one targeted check: all 36 prior per-channel Normalize cells against
an independent float64 oracle, to rule out shared C/K/NumPy errors in retained
timing cells. All 34 retained cells pass. Both excluded routes pass after only
disabling Haswell. No package/runtime changes and no upstream publication.
