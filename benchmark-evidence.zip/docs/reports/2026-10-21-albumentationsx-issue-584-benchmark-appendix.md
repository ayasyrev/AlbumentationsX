# Issue #584: benchmark appendix

This appendix accompanies the local PR description. The archive
`2026-10-21-albumentationsx-issue-584-benchmark-evidence.zip` contains the full
tables, raw results, validation records and reproduction scripts. It is a local
publication attachment; no upload or public attachment URL is claimed here.

## Comparisons

- Original baseline versus the C-order fix: [120 cells, CSV](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark-cells.csv),
  [rendered table](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark-cells.md),
  [raw samples and environment](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark.json),
  [harness](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark.py).
- Expanded baseline/C/K comparison: [671 cells, CSV](2026-10-21-albumentationsx-issue-584-order-k-evidence/cells.csv),
  [raw main results](2026-10-21-albumentationsx-issue-584-order-k-evidence/benchmark.json),
  [callback supplement](2026-10-21-albumentationsx-issue-584-order-k-evidence/callbacks.json),
  [method and reproduction commands](2026-10-21-albumentationsx-issue-584-order-k-evidence/README.md).

The two matrices are distinct runs, not 791 independent workloads. The PR's
seven-row table comes exclusively from the expanded CSV. Its row IDs, in order,
are `df8f8c7b3cb2`, `4bf7b6b67ba2`, `3f8a63c9796e`, `1f8bafa30116`,
`be0833352e91`, `c79f037913d8`, `460b78bb7515`. The small writable-bridge
overhead range is from the original run. No new timings were collected while
preparing this appendix.

Baseline: `45a1afe21448fd2e83716733e2880c00335060fb`.
C-order fix: `ff6db7b86e9094112a2e5a0ba2268ab4f199791f`.
K changes only the copy-order argument for the experiment; it is not part of
the fix. Exact helper snapshots and source hashes are in the expanded evidence.

## Reading the results

Times are medians for each variant; percentages are medians of paired ratios.
Their displayed rounded values need not reproduce the percentage by division.
The baseline is unsafe for readonly storage. No diagnostic writes were made
through its readonly-backed Tensors. All comparisons include allocation and the
named pipeline/consumer work; validation, hashing and result logging are outside
the timer. Apparent regressions above 5% received additional paired rounds.

Expanded timing includes 635 main cases and 36 callbacks, with exact C/K output
agreement. Two normalization comparisons failed semantic preflight and were
excluded before timing; their full observations remain in the evidence. A
subsequent independent float64 audit found no errors in the 34 retained
per-channel normalization timing cases. The dependency investigation and its
upstream issue draft are maintained separately from the PR description; their
standalone audit records are included as a separate evidence directory in this
archive so the exclusions can be checked.

Results apply to the recorded Linux/Ryzen 7 5800X environment, Python 3.13.14,
NumPy 2.5.1, Torch 2.14.1+cpu and Albucore 0.2.21. This is not a full-suite,
cross-platform, GPU or DataLoader benchmark.

The archive preserves repository-relative paths. `SHA256SUMS.json` at its root
records the SHA-256 of every other archive member. `pr-summary-cells.json`
contains the exact source rows used in the compact PR table.
