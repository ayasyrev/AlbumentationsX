# Issue 584: copy-order experiment evidence

This experiment compares the original helper, reviewed C-order fix and exact
in-memory K-order alternative. Package source is unchanged at
`ff6db7b86e9094112a2e5a0ba2268ab4f199791f`; baseline is
`45a1afe21448fd2e83716733e2880c00335060fb`.

## Files

- `benchmark.py`: complete paired harness, also preserved under the worktree's
  `_internal/issue584_order_k.py`.
- `tensor-baseline.py`, `tensor-C.py`, `tensor-K.py`: exact source snapshots
  extracted from the recorded benchmark; their SHA256 values are in validation.json.
- `preflight.json`: initial 607-cell discovery, including six unsupported
  Equalize C5 calls and two normalization discrepancies.
- `preflight-final.json`: 637 supported cells; 635 pass, two normalization
  comparisons retained under `errors` with all three variants' observations.
- `validated-cells.json`: exact 635-cell timing selection from that preflight.
- `benchmark.json`: all source texts and hashes, parameters, input hashes,
  effective thread settings, output layouts, copy conditions and raw timings.
- `callbacks.py` / `callbacks.json`: public Compose + Lambda supplement for
  readonly stepped and writable negative-stride interleaved results. It reuses
  the archived main harness and records both source hashes.
- `cells.csv` / `summary.json`: all 671 final cells and grouped summaries.
  `summarize.py` derives these from the raw records.
- `control-rerun-cells.json`, `retry.json/log`: five no-copy float32 controls
  whose initial apparent >5% speedups disappeared on the longer paired repeat.
  Final CSV uses the repeat; original measurements remain in `benchmark.json`.
- `normalize_layout.py` / `normalize-layout-oracle.json`: independent float64
  oracle and direct NumKong moments reproducer for the dependency discrepancy.
- `normalize-diagnostic.json`: baseline/C/K public route comparison for the two
  excluded normalization cells. For standalone Tensor Normalize, all helpers
  agree and the NumPy oracle route is defective. In Gamma → per-channel
  Normalize, K and baseline retain the defective interleaved layout while C
  incidentally bypasses it.
- `run_existing_tests.py`, `focused-k.log/xml`, `adjacent-k.log/xml`: run existing
  tests under the in-memory K helper. Tests run in one process so the helper
  injection applies to every test; no xdist workers or package edits are used.

## Reproduction

Use a worktree-local locked environment with dev and ci-torch-cpu dependencies.
Install the baseline from its Git archive into an isolated target directory,
then run from outside the source checkout. The earlier issue-584 report records
the successful baseline installation commands. This session reused that exact
installation; its tensor.py hash matches `git show` of the baseline revision.

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export UV_CACHE_DIR=/tmp/albu-584-uv-cache
cd /tmp
uv run --project /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor --no-sync python \
  /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor/_internal/issue584_order_k.py \
  --baseline /tmp/albu-584-baseline-installed \
  --candidate /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor/albumentations/core/tensor.py \
  --phase benchmark \
  --select /home/albu/Prj/Albu_Base/docs/reports/2026-10-21-albumentationsx-issue-584-order-k-evidence/validated-cells.json \
  --output /tmp/issue584-order-k-benchmark.json
```

Use `--phase preflight` without `--select` to repeat all supported semantic
cases, including the two known failures. Exit 1 is expected for that manifest
with this locked NumKong version; do not mistake it for an all-pass result.
Use `--phase retry --select <JSON array of cell IDs>` for longer investigations.

The callbacks supplement was run with the same environment from `/tmp`:

```bash
uv run --project /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor --no-sync python \
  /home/albu/Prj/Albu_Base/docs/reports/2026-10-21-albumentationsx-issue-584-order-k-evidence/callbacks.py \
  /tmp/albu-584-baseline-installed \
  /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor/albumentations/core/tensor.py
```

Main, callbacks and control-repeat commands all exited 0. The supported full
semantic preflight exited 1 for the two preserved normalization discrepancies;
the initial discovery also included six documented unsupported Equalize C5
inputs. Existing K-injected suites completed with 576 and 1,526 passes, exit 0.

The existing regression suite commands (same thread environment as above) were:

```bash
cd /home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor
uv run --no-sync python _internal/issue584_k_tests.py -n 0 -q \
  tests/test_tensor_bridge.py tests/test_tensor_compose.py \
  --randomly-seed=137 --hypothesis-profile=ci-fast \
  --junitxml=/home/albu/Prj/Albu_Base/docs/reports/2026-10-21-albumentationsx-issue-584-order-k-evidence/focused-k.xml
uv run --no-sync python _internal/issue584_k_tests.py -n 0 -q \
  tests/contracts/test_target_cluster_contract.py tests/test_compose_reentrancy.py \
  tests/test_composition_tracing.py tests/test_annotation_artifacts.py \
  -k 'tensor or Tensor' --randomly-seed=137 --hypothesis-profile=ci-fast \
  --junitxml=/home/albu/Prj/Albu_Base/docs/reports/2026-10-21-albumentationsx-issue-584-order-k-evidence/adjacent-k.xml
```

Their stdout/stderr was redirected to the matching `.log` files. The source of
`_internal/issue584_k_tests.py` is archived here as `run_existing_tests.py`.
The independent normalization probe was run from `/tmp`, with the same uv project
and thread environment, as
`python _internal/issue584_normalize_layout.py <evidence>/normalize-layout-oracle.json`
(the original command used absolute paths). Its archived source is `normalize_layout.py`.

Each timing block measures all calls, including allocation and full Compose /
consumer execution. Observers, equality checks, hashing and JSON writes are
outside timing blocks. The baseline remains unsafe for readonly storage; no
diagnostic writes through its readonly-backed Tensors are performed.

Reported percentages are medians of paired round-by-round time ratios. Absolute
times are medians in each variant; dividing these two displayed medians can
therefore give a slightly different percentage. `stack8` repeats one output
eight times to isolate layout cost; actual independently augmented items are
covered separately by the `per_image_stack` route at N4/N8/N16.
