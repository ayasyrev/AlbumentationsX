"""Persistent paired storage-order experiment; never modifies package source."""

import argparse
import gc
import hashlib
import itertools
import json
import math
import os
import platform
import statistics
import sys
import time
import types
import warnings
from pathlib import Path


def arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--baseline", type=Path, required=True)
    parser.add_argument("--candidate", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--phase", choices=("preflight", "benchmark", "retry"), default="preflight")
    parser.add_argument("--select", type=Path)
    return parser.parse_args()


args = arguments()
sys.path.insert(0, str(args.baseline.resolve()))

import albucore
import albumentations as A
import cv2
import numkong as nk
import numpy as np
import torch
from albumentations.core import tensor as bridge

assert Path(A.__file__).is_relative_to(args.baseline)
cv2.setNumThreads(0)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
torch.manual_seed(137)

source_c = args.candidate.read_text()
needle = 'np.array(value, copy=True, order="C")'
assert source_c.count(needle) == 1
sources = {"baseline": Path(bridge.__file__).read_text(), "C": source_c,
           "K": source_c.replace(needle, 'np.array(value, copy=True, order="K")')}
helpers = {"baseline": bridge._numpy_to_tensor}
for variant in ("C", "K"):
    module = types.ModuleType(f"order_{variant}")
    exec(compile(sources[variant], f"<tensor-order-{variant}>", "exec"), module.__dict__)
    helpers[variant] = module._numpy_to_tensor

AXES = {"image": (2, 0, 1), "images": (0, 3, 1, 2),
        "volume": (3, 0, 1, 2), "volumes": (0, 4, 1, 2, 3)}


def transform_specs(name: str, shape: tuple[int, ...]) -> list[dict]:
    channels = shape[-1]
    specs = {
        "gamma": ("RandomGamma", {"gamma_range": (137, 137)}),
        "brightness_max": ("RandomBrightnessContrast", {
            "brightness_range": (0.1, 0.1), "contrast_range": (0.2, 0.2), "brightness_by_max": True}),
        "brightness_mean": ("RandomBrightnessContrast", {
            "brightness_range": (0.1, 0.1), "contrast_range": (0.2, 0.2), "brightness_by_max": False}),
        "invert": ("InvertImg", {}),
        "solarize": ("Solarize", {"threshold_range": (0.5, 0.5)}),
        "posterize": ("Posterize", {"num_bits": (4, 4)}),
        "equalize": ("Equalize", {"mode": "cv", "by_channels": True}),
        "blur": ("GaussianBlur", {"blur_range": (5, 5), "sigma_range": (1.1, 1.1)}),
        "flip": ("HorizontalFlip", {}),
        "resize": ("Resize", {"height": shape[-3] // 2, "width": shape[-2] // 2}),
        "normalize": ("Normalize", {"normalization": "image_per_channel"}),
        "normalize_standard": ("Normalize", {"mean": 0.5, "std": 0.25, "normalization": "standard"}),
        "rgb_shift": ("RGBShift", {"r_shift_range": (13, 13), "g_shift_range": (-7, -7),
                                    "b_shift_range": (5, 5)}),
        "hsv": ("HueSaturationValue", {"hue_shift_range": (0 if channels == 1 else 7,) * 2,
                                       "sat_shift_range": (0 if channels == 1 else 11,) * 2,
                                       "val_shift_range": (5, 5)}),
        "clahe": ("CLAHE", {"clip_range": (2, 2), "tile_grid_size": (8, 8)}),
    }
    result = []
    for part in name.split("+"):
        cls, kwargs = specs[part]
        result.append({"class": cls, "kwargs": {**kwargs, "p": 1.0}})
    return result


def manifest() -> list[dict]:
    rows = []

    def add(route, target, shape, dtype, transform="", storage="tensor", consumer="none", layout="contiguous"):
        row = dict(route=route, target=target, shape=list(shape), dtype=dtype, transform=transform,
                   storage=storage, consumer=consumer, input_layout=layout)
        if transform:
            row["transforms"] = transform_specs(transform, shape)
        row["id"] = hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()[:12]
        rows.append(row)

    for size, channels, dtype in itertools.product((256, 512, 1024), (1, 3, 5), ("uint8", "float16", "float32")):
        for storage in ("writable", "readonly_c", "readonly_f", "readonly_positive", "negative"):
            add("bridge", "image", (size, size, channels), dtype, storage=storage)
    general = ("gamma", "brightness_max", "brightness_mean", "invert", "solarize", "posterize",
               "blur", "flip", "resize", "normalize", "normalize_standard")
    for size, channels, dtype in itertools.product((256, 512, 1024), (1, 3, 5), ("uint8", "float32")):
        for name in general + (("rgb_shift",) if channels == 3 else ()) + (
            ("equalize", "hsv", "clahe") if channels != 5 else ()
        ):
            add("compose", "image", (size, size, channels), dtype, transform=name)
        for name in ("gamma+blur", "gamma+brightness_mean", "gamma+normalize", "gamma+normalize_standard", "gamma+flip"):
            add("chain", "image", (size, size, channels), dtype, transform=name)
        for consumer in ("contiguous", "float32", "stack8", "conv2d"):
            add("consumer", "image", (size, size, channels), dtype, transform="gamma", consumer=consumer)
    for batch, dtype, name in itertools.product((4, 8, 16), ("uint8", "float32"),
                                               ("gamma", "brightness_mean", "blur")):
        for route in ("batch", "per_image_stack"):
            add(route, "images", (batch, 256, 256, 3), dtype, transform=name)
    for channels, dtype, name in itertools.product((1, 3, 5), ("uint8", "float32"),
                                                  ("gamma", "brightness_mean", "blur")):
        add("volume", "volume", (4, 64, 64, channels), dtype, transform=name)
        add("volume", "volumes", (2, 4, 64, 64, channels), dtype, transform=name)
    for size, dtype, name in itertools.product((256, 1024), ("uint8", "float32"),
                                              ("gamma", "brightness_mean", "blur", "resize")):
        add("channel_boundary", "image", (size, size, 4), dtype, transform=name)
    for layout, dtype, name in itertools.product(("channels_last", "positive"), ("uint8", "float32"),
                                                ("gamma", "brightness_mean", "blur")):
        add("input_layout", "image", (384, 512, 3), dtype, transform=name, layout=layout)
    return rows


def array_hash(value) -> str:
    return hashlib.sha256(np.asarray(value).tobytes()).hexdigest()


def make_input(row: dict):
    shape = tuple(row["shape"])
    logical = np.random.default_rng(137).uniform(0.1, 0.9, shape).astype(np.float32)
    value = (logical * 255).astype(np.uint8) if row["dtype"] == "uint8" else logical.astype(row["dtype"])
    if row["route"] == "bridge":
        storage = row["storage"]
        if storage == "readonly_f":
            value = np.asfortranarray(value)
        elif storage == "readonly_positive":
            backing = np.empty((*shape[:-2], shape[-2] * 2, shape[-1]), dtype=value.dtype)
            backing[..., ::2, :] = value
            value = backing[..., ::2, :]
        elif storage == "negative":
            value = value[..., ::-1, :]
        if storage.startswith("readonly"):
            value.setflags(write=False)
        return value
    value = torch.from_numpy(value.transpose(AXES[row["target"]]))
    if row["input_layout"] != "channels_last":
        value = value.contiguous()
    if row["input_layout"] == "positive":
        backing = torch.empty((*value.shape[:-1], value.shape[-1] * 2), dtype=value.dtype)
        backing[..., ::2] = value
        value = backing[..., ::2]
    return value


def make_pipeline(row: dict):
    return A.Compose([getattr(A, spec["class"])(**spec["kwargs"]) for spec in row["transforms"]],
                     seed=137, strict=True)


def consumer_factory(row: dict):
    consumer = row["consumer"]
    if consumer == "contiguous":
        return lambda value: value.contiguous()
    if consumer == "float32":
        return lambda value: value.to(torch.float32)
    if consumer == "stack8":
        return lambda value: torch.stack([value] * 8)
    if consumer == "conv2d":
        weights = torch.from_numpy(np.random.default_rng(137).uniform(
            -0.1, 0.1, (8, row["shape"][-1], 3, 3)).astype(np.float32))
        return lambda value: torch.nn.functional.conv2d(value.to(torch.float32).unsqueeze(0), weights, padding=1)
    return lambda value: value


def make_calls(row: dict, source):
    if row["route"] == "bridge":
        expected = torch.from_numpy(source.transpose(AXES[row["target"]]).copy())
        return lambda: bridge.numpy_to_tensor_spatial(source, row["target"]), expected
    pipeline = make_pipeline(row)
    oracle = make_pipeline(row)
    consume = consumer_factory(row)
    target = row["target"]
    numpy_input = bridge.tensor_to_numpy_spatial(source, target).copy()
    if row["route"] == "per_image_stack":
        expected_arrays = [oracle(image=item)["image"] for item in numpy_input]
        expected = torch.from_numpy(np.stack(expected_arrays).transpose(AXES[target]).copy())
        call = lambda: torch.stack([pipeline(image=item)["image"] for item in source])
    else:
        expected_array = oracle(**{target: numpy_input})[target]
        expected = torch.from_numpy(expected_array.transpose(AXES[target]).copy())
        call = lambda: consume(pipeline(**{target: source})[target])
    return call, consume(expected)


def verify(row: dict, call, expected, source) -> dict:
    before = array_hash(source)
    outputs = {}
    details = {}
    oracle_errors = {}
    for variant in ("baseline", "C", "K"):
        observations = []

        def observed(value):
            result = helpers[variant](value)
            copies = not value.flags.writeable or any(stride < 0 for stride in value.strides)
            shares = np.shares_memory(value, result.numpy())
            if variant != "baseline" and value.size:
                assert shares == (not copies), (variant, shares, copies)
            observations.append(dict(shape=list(value.shape), strides=list(value.strides),
                                     writeable=value.flags.writeable, copy_required=copies,
                                     shares_storage=shares, output_strides=list(result.stride()), bytes=value.nbytes))
            return result

        bridge._numpy_to_tensor = observed
        with warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter("always")
            result = call()
        readonly_warnings = [str(item.message) for item in caught if "not writable" in str(item.message)]
        if variant != "baseline":
            assert not readonly_warnings
        assert result.dtype == expected.dtype
        try:
            if result.is_floating_point():
                torch.testing.assert_close(result, expected, rtol=2e-5, atol=2e-5)
            else:
                torch.testing.assert_close(result, expected, rtol=0, atol=0)
        except AssertionError as error:
            oracle_errors[variant] = str(error)
        outputs[variant] = result
        details[variant] = dict(bridge=observations, output_shape=list(result.shape),
                                output_strides=list(result.stride()), contiguous=result.is_contiguous(),
                                readonly_warnings=readonly_warnings,
                                minimum=float(result.min()), maximum=float(result.max()),
                                max_oracle_error=float((result.to(torch.float64) - expected).abs().max()))
    c_k_error = None
    try:
        torch.testing.assert_close(outputs["C"], outputs["K"], rtol=2e-5, atol=2e-5)
    except AssertionError as error:
        c_k_error = str(error)
    assert array_hash(source) == before
    return {"input_sha256": before, "variants": details, "oracle_errors": oracle_errors, "c_k_error": c_k_error,
            "max_c_k_error": float((outputs["C"].to(torch.float64) - outputs["K"]).abs().max())}


def elapsed(call, count: int) -> float:
    start = time.perf_counter_ns()
    for _ in range(count):
        call()
    return (time.perf_counter_ns() - start) / count


def paired(call, count: int, rounds: int) -> dict:
    samples = {variant: [] for variant in helpers}
    orders = list(itertools.permutations(helpers))
    for round_index in range(rounds):
        for variant in orders[round_index % len(orders)]:
            bridge._numpy_to_tensor = helpers[variant]
            samples[variant].append(elapsed(call, count))
    medians = {variant: statistics.median(values) for variant, values in samples.items()}
    pairs = {}
    for previous, following in (("baseline", "C"), ("baseline", "K"), ("C", "K")):
        ratios = [(right / left - 1) * 100 for left, right in zip(samples[previous], samples[following])]
        pairs[f"{following}_vs_{previous}"] = dict(
            median_percent=statistics.median(ratios), median_time_percent=(medians[following] / medians[previous] - 1) * 100,
            min_percent=min(ratios), max_percent=max(ratios), samples_percent=ratios)
    return dict(samples_ns=samples, medians_ns=medians, comparisons=pairs)


rows = manifest()
if args.select:
    selected = set(json.loads(args.select.read_text()))
    rows = [row for row in rows if row["id"] in selected]
report = dict(
    baseline_revision="45a1afe21448fd2e83716733e2880c00335060fb",
    reviewed_revision="ff6db7b86e9094112a2e5a0ba2268ab4f199791f", phase=args.phase,
    candidate_description='Reviewed source, with only np.array order="C" replaced by order="K" in memory',
    sources=sources, hashes={name: hashlib.sha256(text.encode()).hexdigest() for name, text in sources.items()},
    harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    method=dict(warmup=20, rounds=6, investigation_rounds=12, order="all 6 permutations in rotation",
                fast_min_calls=100, fast_threshold_ns=2_000_000, slow_aggregate_target_ns=1_000_000_000,
                float_tolerance=dict(rtol=2e-5, atol=2e-5)),
    environment=dict(python=sys.version, platform=platform.platform(), cpu_count=os.cpu_count(),
                     cpu_model=next(line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
                                    if line.startswith("model name")),
                     albumentations_import=A.__file__, baseline_tensor=bridge.__file__,
                     numpy=np.__version__, torch=torch.__version__, opencv=cv2.__version__,
                     albucore=albucore.__version__, albucore_import=albucore.__file__,
                     capabilities=nk.get_capabilities(), torch_threads=torch.get_num_threads(),
                     torch_interop=torch.get_num_interop_threads(), cv2_threads=cv2.getNumThreads(),
                     thread_env={key: os.environ.get(key) for key in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                                 "MKL_NUM_THREADS", "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")},
                     load_start=os.getloadavg()), manifest=rows, results=[], errors=[],
    excluded_contracts=["Equalize C5: documented supported channels are 1 and 3; six initial probes rejected"])
args.output.parent.mkdir(parents=True, exist_ok=True)
gc.disable()
for index, row in enumerate(rows, 1):
    try:
        source = make_input(row)
        call, expected = make_calls(row, source)
        check = verify(row, call, expected, source)
        result = {**row, "semantic": check}
        if check["oracle_errors"] or check["c_k_error"]:
            report["errors"].append(result)
            print(f"SEMANTIC {row['id']} {row['transform']}: oracle={list(check['oracle_errors'])}, "
                  f"C/K equal={check['c_k_error'] is None}", flush=True)
            continue
        if args.phase != "preflight":
            for variant in helpers:
                bridge._numpy_to_tensor = helpers[variant]
                for _ in range(20):
                    call()
            bridge._numpy_to_tensor = helpers["K"]
            duration = elapsed(call, 5)
            count = max(100, min(5000, math.ceil(30_000_000 / duration))) if duration < 2_000_000 else max(
                10, math.ceil(1_000_000_000 / (18 * duration)))
            if args.phase == "retry":
                count = max(count, math.ceil(100_000_000 / duration))
            result["iterations_per_round"] = count
            result["initial"] = paired(call, count, 12 if args.phase == "retry" else 6)
            changes = result["initial"]["comparisons"]
            if args.phase == "benchmark" and any(item["median_percent"] > 5 for item in changes.values()):
                result["investigation"] = paired(call, count, 12)
            assert array_hash(source) == check["input_sha256"]
        report["results"].append(result)
    except Exception as error:
        report["errors"].append({**row, "error": repr(error)})
        print(f"ERROR {row['id']} {row['transform']} {row['shape']} {row['dtype']}: {error}", flush=True)
    if index % 10 == 0 or index == len(rows):
        print(f"{args.phase}: {index}/{len(rows)}, errors={len(report['errors'])}, load={os.getloadavg()}", flush=True)
        report["environment"]["load_latest"] = os.getloadavg()
        args.output.write_text(json.dumps(report, indent=2, default=str) + "\n")
gc.enable()
report["environment"]["load_end"] = os.getloadavg()
args.output.write_text(json.dumps(report, indent=2, default=str) + "\n")
print(f"Complete: {len(report['results'])} passed; {len(report['errors'])} errors", flush=True)
raise SystemExit(bool(report["errors"]))
