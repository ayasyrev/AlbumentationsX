"""Public Compose callbacks exposing interleaved sliced and negative-stride results."""

import gc
import hashlib
import itertools
import json
import math
import sys
from pathlib import Path

root = Path(__file__).resolve().parent
script_args = sys.argv[1:]
assert len(script_args) == 2, "arguments: installed-baseline-directory candidate-tensor.py"
empty = root / "empty-selection.json"
empty.write_text("[]\n")
sys.argv = [str(root / "benchmark.py"), "--baseline", script_args[0], "--candidate", script_args[1],
            "--output", str(root / "callback-setup.json"), "--select", str(empty)]
# Reuse the exact definitions and metadata without running the timing driver.
namespace = {"__file__": str(root / "benchmark.py"), "__name__": "issue584_callbacks"}
text = (root / "benchmark.py").read_text()
exec(compile(text[:text.index("\ngc.disable()")], str(root / "benchmark.py"), "exec"), namespace)
A, np, bridge = namespace["A"], namespace["np"], namespace["bridge"]


def callback_pipeline(row):
    def operation(value, **params):
        value = np.array(value, copy=True, order="C")
        if row["transform"] == "callback_readonly_slice":
            value = value[:, ::2, :]
            value.setflags(write=False)
            return value
        return value[:, ::-1, :]

    return A.Compose([A.Lambda(image=operation, p=1.0)], seed=137, strict=True)


namespace["make_pipeline"] = callback_pipeline
report = namespace["report"]
report.update(phase="callbacks", harness_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              reused_harness_sha256=hashlib.sha256(text.encode()).hexdigest(),
              callback_contract="Allocate interleaved C storage, then return readonly width-step-2 or writable width-reversed view")
report["method"]["calibration"] = "maximum of all three variant durations; same count for all variants in each cell"
report["results"] = []
report["errors"] = []
report["manifest"] = []
for size, channels, dtype, name in itertools.product((256, 512, 1024), (1, 3, 5), ("uint8", "float32"),
                                                    ("callback_readonly_slice", "callback_negative")):
    row = dict(route="callback", target="image", shape=[size, size, channels], dtype=dtype,
               transform=name, storage="tensor", consumer="none", input_layout="contiguous")
    row["id"] = hashlib.sha256(json.dumps(row, sort_keys=True).encode()).hexdigest()[:12]
    report["manifest"].append(row)
gc.disable()
for index, row in enumerate(report["manifest"], 1):
    source = namespace["make_input"](row)
    call, expected = namespace["make_calls"](row, source)
    check = namespace["verify"](row, call, expected, source)
    assert not check["oracle_errors"] and not check["c_k_error"]
    durations = []
    for variant, helper in namespace["helpers"].items():
        bridge._numpy_to_tensor = helper
        for _ in range(20):
            call()
        durations.append(namespace["elapsed"](call, 5))
    duration = max(durations)
    count = max(100, min(5000, math.ceil(30_000_000 / duration))) if duration < 2_000_000 else max(
        10, math.ceil(1_000_000_000 / (18 * duration)))
    result = {**row, "semantic": check, "iterations_per_round": count,
              "initial": namespace["paired"](call, count, 6)}
    if any(value["median_percent"] > 5 for value in result["initial"]["comparisons"].values()):
        result["investigation"] = namespace["paired"](call, count, 12)
    assert namespace["array_hash"](source) == check["input_sha256"]
    report["results"].append(result)
    report["environment"]["load_end"] = namespace["os"].getloadavg()
    (root / "callbacks.json").write_text(json.dumps(report, indent=2) + "\n")
    print(f"callbacks: {index}/{len(report['manifest'])}", flush=True)
print("Complete: callbacks passed")
