"""Independent float64 oracle for the normalization layout discrepancy."""

import importlib.metadata
import json
import sys
from pathlib import Path

import albucore
import cv2
import numkong as nk
import numpy as np
import torch

cv2.setNumThreads(0)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
report = {"albucore": albucore.__version__, "numkong": importlib.metadata.version("numkong"),
          "numpy": np.__version__, "cases": []}
for size in (512, 768, 1024):
    for channels in (1, 3, 4, 5):
        original = (np.random.default_rng(137).uniform(0.1, 0.9, (size, size, channels)).astype(np.float32) * 255).astype(
            np.uint8)
        for layout in ("interleaved", "planar"):
            value = original if layout == "interleaved" else original.transpose(2, 0, 1).copy().transpose(1, 2, 0)
            expected_mean = value.mean(axis=(0, 1), dtype=np.float64)
            expected_std = value.std(axis=(0, 1), dtype=np.float64) + 1e-4
            actual_mean, actual_std = albucore.mean_std(value, "per_channel")
            expected = np.clip((value.astype(np.float64) - expected_mean) / expected_std, -20, 20)
            actual = albucore.normalize_per_image(value, "image_per_channel")
            expected_sum = np.sum(value[..., 0], dtype=np.uint64)
            expected_square_sum = np.sum(value[..., 0].astype(np.uint64) ** 2, dtype=np.uint64)
            observed_sum, observed_square_sum = nk.moments(value[..., 0])
            report["cases"].append({
                "size": size, "channels": channels, "layout": layout, "strides": value.strides,
                "expected_mean": expected_mean.tolist(), "actual_mean": np.asarray(actual_mean).tolist(),
                "expected_std": expected_std.tolist(), "actual_std": np.asarray(actual_std).tolist(),
                "max_error": float(np.max(np.abs(actual - expected))),
                "expected_sum_first_channel": int(expected_sum), "nk_sum_first_channel": int(observed_sum),
                "expected_square_sum_first_channel": int(expected_square_sum),
                "nk_square_sum_first_channel": int(observed_square_sum),
                "expected_range": [float(expected.min()), float(expected.max())],
                "actual_range": [float(actual.min()), float(actual.max())],
            })
Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + "\n")
for row in report["cases"]:
    if row["max_error"] > 1e-4:
        print(row)
print(f"Checked {len(report['cases'])} cases")
