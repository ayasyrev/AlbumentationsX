"""Run existing regression suites with the exact in-memory K-order alternative."""

import hashlib
import sys
import types
from pathlib import Path

import cv2
import pytest
import torch
from albumentations.core import tensor as bridge

cv2.setNumThreads(0)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
source = Path(bridge.__file__).read_text()
needle = 'np.array(value, copy=True, order="C")'
assert source.count(needle) == 1
candidate = source.replace(needle, 'np.array(value, copy=True, order="K")')
module = types.ModuleType("in_memory_order_k")
exec(compile(candidate, "<tensor-order-K>", "exec"), module.__dict__)
bridge._numpy_to_tensor = module._numpy_to_tensor
print(f"Imported: {bridge.__file__}", flush=True)
print(f"K source sha256: {hashlib.sha256(candidate.encode()).hexdigest()}", flush=True)
raise SystemExit(pytest.main(sys.argv[1:]))
