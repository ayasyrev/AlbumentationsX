"""Export all paired cells and bounded summaries without dropping regressions."""

import collections
import csv
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
report = json.loads((root / "benchmark.json").read_text())
source_rows = list(report["results"])
all_errors = list(report["errors"])
if (root / "callbacks.json").exists():
    callbacks = json.loads((root / "callbacks.json").read_text())
    source_rows.extend(callbacks["results"])
    all_errors.extend(callbacks["errors"])
retries = {}
if (root / "retry.json").exists():
    retries = {row["id"]: row for row in json.loads((root / "retry.json").read_text())["results"]}
rows = []
for source in source_rows:
    latest = retries.get(source["id"], source)
    result = latest.get("investigation", latest["initial"])
    row = {key: source[key] for key in ("id", "route", "transform", "target", "dtype", "storage",
                                      "consumer", "input_layout")}
    row.update(shape="x".join(map(str, source["shape"])), channels=source["shape"][-1],
               output_shape="x".join(map(str, source["semantic"]["variants"]["K"]["output_shape"])),
               C_output_strides=str(source["semantic"]["variants"]["C"]["output_strides"]),
               K_output_strides=str(source["semantic"]["variants"]["K"]["output_strides"]),
               iterations_per_round=latest["iterations_per_round"],
               rounds=len(result["samples_ns"]["K"]),
               evidence="retry" if source["id"] in retries else (
                   "investigation" if "investigation" in source else "initial"),
               bridge_copies=sum(item["copy_required"] for item in source["semantic"]["variants"]["K"]["bridge"]),
               copied_bytes=sum(item["bytes"] for item in source["semantic"]["variants"]["K"]["bridge"]
                                if item["copy_required"]))
    for name, value in result["medians_ns"].items():
        row[f"{name}_us"] = value / 1000
    for comparison, values in result["comparisons"].items():
        row[f"{comparison}_percent"] = values["median_percent"]
        row[f"{comparison}_min_percent"] = values["min_percent"]
        row[f"{comparison}_max_percent"] = values["max_percent"]
    rows.append(row)
with (root / "cells.csv").open("w") as stream:
    writer = csv.DictWriter(stream, fieldnames=rows[0])
    writer.writeheader()
    writer.writerows(rows)

groups = collections.defaultdict(list)
for row in rows:
    group = (row["route"], row["transform"] or row["storage"], row["dtype"], row["consumer"])
    groups[group].append(row)
summary = []
for group, cells in groups.items():
    record = dict(zip(("route", "transform_or_storage", "dtype", "consumer"), group))
    record["count"] = len(cells)
    for comparison in ("C_vs_baseline", "K_vs_baseline", "K_vs_C"):
        values = [row[f"{comparison}_percent"] for row in cells]
        record[comparison] = dict(median=statistics.median(values), minimum=min(values), maximum=max(values),
                                  above_5=sum(value > 5 for value in values), below_minus_5=sum(value < -5 for value in values))
    summary.append(record)
summary.sort(key=lambda row: (row["route"], row["transform_or_storage"], row["dtype"], row["consumer"]))
output = dict(cells=len(rows), benchmark_errors=all_errors, investigations=sum("investigation" in row
    for row in source_rows), retries=len(retries), groups=summary,
    k_c_regressions=sorted([row for row in rows if row["K_vs_C_percent"] > 5],
                          key=lambda row: row["K_vs_C_percent"], reverse=True),
    k_c_wins=sorted([row for row in rows if row["K_vs_C_percent"] < -5], key=lambda row: row["K_vs_C_percent"]))
(root / "summary.json").write_text(json.dumps(output, indent=2) + "\n")
(root / "regression-cells.json").write_text(json.dumps([row["id"] for row in output["k_c_regressions"]], indent=2) + "\n")
print(json.dumps({key: output[key] for key in ("cells", "investigations", "retries")}, indent=2))
print(f"K/C >5%: {len(output['k_c_regressions'])}; K/C <-5%: {len(output['k_c_wins'])}")
