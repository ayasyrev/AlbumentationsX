# #584: расширенная проверка порядка копирования

**Универсальная замена C-order на K-order не рекомендуется.** K сокращает время
ряда uint8-трансформаций и NumPy-цепочек, но ухудшает обработку некоторых срезов
и последующих Tensor-операций. Найден также layout-sensitive дефект зависимости
в цепочке Gamma → per-channel Normalize. Для узкого #584 оставлен проверенный
коммит с C-order; K не применялся к исходникам.

Проверка по запросу пользователя от 21 октября 2026 года. Сравниваются исходный
helper `45a1afe2`, проверенный фикс с C-order `ff6db7b8` и его вариант с единственной
заменой `order="C"` на `order="K"` в памяти. Исходники пакета не менялись.

План: [order-k](../plans/2026-10-21-albumentationsx-issue-584-order-k.md).
Полные данные и воспроизведение: [evidence](2026-10-21-albumentationsx-issue-584-order-k-evidence/README.md).

## Корректность

- Под K-order повторены **576 focused + 1 526 adjacent = 2 102** существующих
  теста. Обе команды завершились с exit 0. Включены все 452 bridge cases.
- Расширенный semantic preflight: **637 поддерживаемых комбинаций**,
  **635 passed**, два расхождения с NumPy oracle, exit 1. Все 635 успешных
  сравнений C/K дали точное совпадение значений; tolerance для сравнения с
  независимым NumPy Compose был `rtol=atol=2e-5` для float и ноль для integer.
- Шесть первоначальных Equalize C5 probes отвергнуты согласно документированному
  контракту C1/C3. Это неподдерживаемые входы; они не включены в timing matrix.
- Зафиксированы shape, dtype, strides, необходимость копии, sharing, исходные
  hashes и неизменность входов. В копирующих ветках C и K отделяют память;
  writable-пути сохраняют zero-copy. Опасные записи через baseline не выполнялись.
- Ещё **36 public Compose + Lambda** случаев прошли проверку значений и
  владения памятью перед замерами. Callback сначала создаёт interleaved array,
  затем возвращает readonly-срез по ширине либо отрицательный stride по ширине.
  Это 256/512/1024 × C1/C3/C5 × uint8/float32 × два callback.

## Найденная зависимость от layout в Normalize

В установленной связке Albucore **0.2.21** и NumKong **7.8.4** воспроизведён
отдельный дефект `nk.moments` на некоторых interleaved uint8-массивах.
Это прямой вызов NumKong на writable NumPy input, без AlbumentationsX/Torch.

Независимый float64 oracle проверил 24 комбинации: стороны 512/768/1024,
C1/C3/C4/C5, interleaved/planar. На 1024×1024×4 и ×5 interleaved сумма квадратов
ошибочна на кратное 2**32. Например, для первого канала C5:

| Величина | Float64 / uint64 oracle | NumKong / Albucore |
| --- | ---: | ---: |
| Сумма квадратов | 20 545 546 633 | 11 955 612 041 |
| std с eps | 58,8471358 | 0,0001 |
| Диапазон нормализованного результата | примерно −1,733…1,733 | −20…20 |

Ошибки суммы квадратов указывают на переполнение аккумулятора; точный внутренний
механизм NumKong в этой работе не исправлялся и не устанавливался по его C-коду.

Это объясняет два расхождения preflight при uint8 1024×1024×5:

1. **Normalize(image_per_channel)**: Tensor input planar; baseline/C/K дают
   одинаковый корректный результат. Канонический NumPy Compose получает
   interleaved input и ошибается, поэтому такой oracle недостаточен.
2. **RandomGamma → Normalize(image_per_channel)**: Gamma возвращает interleaved
   readonly storage. C-copy переводит его в planar, обходя ошибку. Baseline и
   K оставляют interleaved layout и дают ошибочный результат, с максимальным
   расхождением с C около 20. Совпадение K с baseline здесь не доказывает
   математическую корректность.

Обе строки исключены из сравнения скорости и сохранены целиком. Стандартная
нормализация с заданными mean/std проверяется отдельно. Дефект зависимости не
исправлялся в рамках проверки #584; изменение lockfile не выполнялось.

## Матрица и метод

13 различных трансформаций, 15 отдельных режимов: RandomGamma,
RandomBrightnessContrast (max/mean), InvertImg, Solarize, Posterize, Equalize,
GaussianBlur, HorizontalFlip, Resize, Normalize (per-channel/standard), RGBShift,
HueSaturationValue, CLAHE. Размеры 256/512/1024, C1/C3/C5 и uint8/float32 там,
где контракт позволяет; отдельные проверки C4 и non-square positive-stride input.
Direct bridge дополнительно проверен на float16, readonly C/F/strided и
negative-stride input.

Batch N4/8/16 сопоставлен с per-image Compose + stack. Volumes D4, collections
N2, C1/C3/C5. Цепочки Gamma → blur/brightness/flip/две нормализации. Отдельные
потребители результата: contiguous(), float32 conversion, stack8, CPU conv2d.

Ryzen 7 5800X / Linux x86-64, Python 3.13.14, NumPy 2.5.1, Torch 2.14.1+cpu,
OpenCV 5.0.0. Окружение принадлежит worktree. Baseline установлен отдельно от
checkout, импортируется из `/tmp/albu-584-baseline-installed`; hash tensor.py
сверен с Git revision. Параметры, входы и зависимости одинаковы у всех вариантов.

Один численный поток; OpenCV parallelism выключен, Torch intra/inter-op = 1.
20 warmups, шесть перестановок baseline/C/K, минимум 100 вызовов быстрых случаев;
для медленных — цель более секунды суммарных измерений. Начальное замедление >5%
проверяется ещё 12 чередующимися раундами. Сравнение включает аллокации, весь
Compose и потребителя результата; observer, oracle, hash и запись JSON находятся
вне таймера. Выводы ограничены этим host/dependency set.

## Результаты времени

**671 уникальная ячейка**: 635 основных + 36 callback. Обе команды завершились
с exit 0. Сделано 250 расследований начальных замедлений >5% (220 + 30), каждое
на 12 дополнительных чередующихся раундах. Ещё пять контрольных «ускорений» без
копирования перепроверены более длинными блоками: исходные −5…−9% исчезли,
результат повторов −0,18…+0,40%, exit 0. Исходные измерения сохранены, итоговый
CSV использует повтор для этих пяти строк.

Полные [671 строки CSV](2026-10-21-albumentationsx-issue-584-order-k-evidence/cells.csv),
[сводка JSON](2026-10-21-albumentationsx-issue-584-order-k-evidence/summary.json) и
[raw timings](2026-10-21-albumentationsx-issue-584-order-k-evidence/benchmark.json).
В 79 ячейках K медленнее C более чем на 5%, в 115 быстрее более чем на 5%,
477 находятся в пределах ±5%. Это счётчики выбранной матрицы, не оценка долей
реальной нагрузки. Все 391 случая без bridge-копирования после повторов находятся
в пределах −4,04…+4,76%; регрессий >5% в этих контролях нет.

Сопоставимые примеры **uint8, input 1024×1024×5**. Проценты — медианы парных
отношений времени; абсолютное время — отдельная медиана по каждому варианту.
Поэтому отношение округлённых времён может немного отличаться от процента.

| Публичный маршрут | C, ms | K, ms | Время K относительно C |
| --- | ---: | ---: | ---: |
| RandomGamma | 5,914 | 4,841 | −18,39% |
| RandomBrightnessContrast, max | 5,936 | 4,898 | −17,24% |
| RandomBrightnessContrast, mean | 13,930 | 12,705 | −8,60% |
| Solarize | 5,863 | 4,796 | −17,34% |
| Gamma → GaussianBlur | 12,009 | 7,110 | −40,91% |
| Gamma → brightness/contrast, mean | 19,779 | 6,058 | −69,22% |
| Gamma → standard Normalize | 12,161 | 6,662 | −45,10% |
| Gamma → contiguous() | 5,999 | 7,182 | +20,55% |
| Gamma → float32 → Conv2d | 54,546 | 58,712 | +6,88% |

Для RandomGamma в этой строке overhead относительно исходного unsafe baseline:
**C +27,06%, K +3,70%**. Это новый запуск того же размера/dtype, не повтор
непредоставленного raw harness независимого ревьюера.

Другие выводы матрицы:

- **Одиночные стандартные трансформации:** K не дал регрессий >5%. Выигрыш
  сосредоточен в многоканальных uint8 Gamma, brightness/contrast и Solarize.
  На float32 полный диапазон после контрольных повторов −3,82…+4,03%.
  Blur, Resize, Equalize, CLAHE, HSV, RGBShift, Invert и Posterize используются
  как контролирующие маршруты без этой readonly-копии в проверенных режимах.
- **Batch/volume:** uint8 batch K/C от −13,15 до +0,27%, volume/volumes
  от −9,74 до +0,49%. Batch и per-image + stack измерены отдельно.
- **Per-image + stack, C3, 256×256, uint8:** при N4/N8/N16 K замедляет Gamma
  на 12,66/11,84/11,05%, brightness/contrast mean на 6,99/6,76/5,39%.
- **Public callback-срезы:** все 24 многоканальных случая медленнее с K,
  от +13,51 до +109,01%. Максимум: float32 512×512×3, negative stride,
  **1,051 → 2,196 ms**. Это полный Compose, включая создание interleaved input
  callback, а не только helper.
- **Direct bridge:** максимальная K/C регрессия +609,20% для readonly stepped
  float16 512×512×3; для uint8 на той же форме +603,52%. Float16 проверяется
  только на helper boundary, публичный Compose по-прежнему его отвергает.
- **Tensor consumers:** K может потерять выигрыш на contiguous(), stack и
  Conv2d. `stack8` — отдельный синтетический layout probe с восемью ссылками
  на один результат; он не выдаётся за измерение DataLoader. Реальные отдельные
  аугментированные элементы представлены per-image + stack выше.

Регрессии распределились по direct bridge (35), callbacks (24), consumers (14)
и per-image + stack (6). Ни у одной итоговой регрессии K/C >5% диапазон парных
раундов не пересекал ноль. Сплошной повтор всей матрицы после этого не выполнялся.

K сохраняет физический порядок плотного interleaved storage и избегает
перепаковки каналов; следующий NumPy-обработчик может получить более удобный
layout. Для strided views NumPy выбирает другой порядок обхода копирования,
а Tensor-потребителю может понадобиться следующая материализация. Поэтому
результат одной Gamma-ячейки не задаёт общую политику bridge.

Локальное описание PR обновлено выводом об отклонённом K-кандидате. Полная новая
матрица вынесена в отдельные файлы; ещё одна большая таблица в PR body не добавлена.

## Границы работы

Не запускались полный pytest suite, DataLoader multiprocessing, macOS/ARM/GPU,
hosted CI и отдельный fresh-process peak-RSS experiment. Оба порядка выполняют
одну копию одинакового payload на несовместимом storage; downstream layout может
добавить следующую копию. Сохранены наблюдаемые объёмы копий, это не peak RSS.

Новые backend, LUT, RNG, vectorization, in-place и grouped-reduction алгоритмы
не вводились: гипотеза касается только порядка единственной NumPy-копии.
Shared Core API consolidation остаётся отдельной задачей. Копии performance
guide в старом coordinator Core checkout и выбранном AX snapshot расходятся;
они не редактировались, cross-repository synchronization/optimization acceptance
в этой работе не объявляется. Для измерений применены более строгие thread и
evidence требования выбранного AX snapshot.

Результаты являются локальной проверкой автора эксперимента, не новым независимым
review. Исходный коммит C-order и прежнее независимое review остаются неизменными;
K-order не принят и не опубликован.
