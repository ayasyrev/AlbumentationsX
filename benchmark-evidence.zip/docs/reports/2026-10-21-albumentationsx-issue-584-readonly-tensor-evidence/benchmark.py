"""Paired #584 storage/Compose measurements against an installed Git baseline."""

import argparse
import gc
import hashlib
import importlib.util
import json
import os
import platform
import statistics
import sys
import time
import warnings
from pathlib import Path

parser = argparse.ArgumentParser()
parser.add_argument("--baseline", type=Path, required=True)
parser.add_argument("--candidate", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.baseline.resolve()))

import albucore
import albumentations as A
import cv2
import numkong as nk
import numpy as np
import torch
from albumentations.core import tensor as bridge

assert Path(A.__file__).is_relative_to(args.baseline)
baseline_helper = bridge._numpy_to_tensor
spec = importlib.util.spec_from_file_location("candidate_tensor", args.candidate)
candidate = importlib.util.module_from_spec(spec)
spec.loader.exec_module(candidate)
candidate_helper = candidate._numpy_to_tensor
helpers = {"baseline": baseline_helper, "candidate": candidate_helper}
cv2.setNumThreads(0)
torch.set_num_threads(1)
torch.set_num_interop_threads(1)
warnings.filterwarnings("ignore", message="The given NumPy array is not writable")


def elapsed(call, count):
    start = time.perf_counter_ns()
    for _ in range(count):
        call()
    return (time.perf_counter_ns() - start) / count


def paired(call, count, rounds):
    samples = {"baseline": [], "candidate": []}
    for round_index in range(rounds):
        order = ("baseline", "candidate") if round_index % 2 == 0 else ("candidate", "baseline")
        for name in order:
            bridge._numpy_to_tensor = helpers[name]
            samples[name].append(elapsed(call, count))
    baseline_ns = statistics.median(samples["baseline"])
    candidate_ns = statistics.median(samples["candidate"])
    return {
        "baseline_ns": baseline_ns,
        "candidate_ns": candidate_ns,
        "change_percent": (candidate_ns / baseline_ns - 1) * 100,
        "paired_change_percent": statistics.median(
            [(after / before - 1) * 100 for before, after in zip(samples["baseline"], samples["candidate"])]
        ),
        "samples_ns": samples,
    }


def tensor_input(value, target):
    axes = {
        "image": (2, 0, 1),
        "images": (0, 3, 1, 2),
        "volume": (3, 0, 1, 2),
        "volumes": (0, 4, 1, 2, 3),
    }
    return torch.from_numpy(value.transpose(axes[target]).copy())


workloads = []
for size in (256, 512, 1024):
    for channels in (1, 3, 5):
        for dtype in (np.uint8, np.float16, np.float32):
            workloads.append(("image", (size, size, channels), dtype))
for batch in (4, 8, 16):
    for dtype in (np.uint8, np.float32):
        workloads.append(("images", (batch, 256, 256, 3), dtype))
for channels in (1, 3):
    for dtype in (np.uint8, np.float32):
        workloads.append(("volume", (4, 64, 64, channels), dtype))
        workloads.append(("volumes", (2, 4, 64, 64, channels), dtype))

rows = []
for target, shape, dtype in workloads:
    logical = np.random.default_rng(137).random(shape, dtype=np.float32)
    value = (logical * 255).astype(dtype) if dtype == np.uint8 else logical.astype(dtype)
    for storage in ("writable", "readonly"):
        source = value if storage == "writable" else np.frombuffer(value.tobytes(), dtype=dtype).reshape(shape)
        rows.append((
            {"route": "bridge", "target": target, "shape": shape, "dtype": str(value.dtype),
             "channels": shape[-1], "storage": storage, "extra_copy_bytes": source.nbytes if storage == "readonly" else 0},
            lambda source=source, target=target: bridge.numpy_to_tensor_spatial(source, target),
            source,
        ))
    if dtype == np.float16:
        continue  # Compose's public Tensor boundary does not accept float16 images.
    source = tensor_input(value, target)
    pipeline = A.Compose([A.RandomGamma(gamma_range=(137, 137), p=1.0)], seed=137, strict=True)
    rows.append((
        {"route": "compose_gamma", "target": target, "shape": shape, "dtype": str(value.dtype),
         "channels": shape[-1], "storage": "tensor", "gamma": 1.37},
        lambda pipeline=pipeline, source=source, target=target: pipeline(**{target: source})[target],
        source,
    ))
    if target == "images":
        rows.append((
            {"route": "compose_gamma_per_image", "target": target, "shape": shape,
             "dtype": str(value.dtype), "channels": shape[-1], "storage": "tensor", "gamma": 1.37},
            lambda pipeline=pipeline, source=source: torch.stack([pipeline(image=item)["image"] for item in source]),
            source,
        ))

cpu_model = next((line.split(":", 1)[1].strip() for line in Path("/proc/cpuinfo").read_text().splitlines()
                  if line.startswith("model name")), platform.processor())
report = {
    "baseline_revision": "45a1afe21448fd2e83716733e2880c00335060fb",
    "baseline_import": A.__file__, "baseline_tensor": bridge.__file__,
    "candidate_tensor": str(args.candidate),
    "source_sha256": {name: hashlib.sha256(Path(path).read_bytes()).hexdigest()
                      for name, path in (("baseline", bridge.__file__), ("candidate", args.candidate))},
    "method": "Installed baseline outside source; alternate only the exact changed helper in the same full pipeline",
    "warmup_calls": 20, "initial_rounds": 5, "investigation_rounds": 11,
    "environment": {
        "python": sys.version, "platform": platform.platform(), "cpu_model": cpu_model,
        "albucore": albucore.__version__, "albucore_import": albucore.__file__,
        "numpy": np.__version__, "torch": torch.__version__, "opencv": cv2.__version__,
        "numkong_capabilities": nk.get_capabilities(),
        "torch_threads": torch.get_num_threads(), "torch_interop_threads": torch.get_num_interop_threads(),
        "opencv_threads": cv2.getNumThreads(),
        "thread_env": {key: os.environ.get(key) for key in (
            "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS",
            "VECLIB_MAXIMUM_THREADS", "NUMEXPR_NUM_THREADS")},
        "load_start": os.getloadavg(),
    },
    "results": [],
}
gc.disable()
for index, (metadata, call, source) in enumerate(rows, 1):
    before_source = source.copy() if isinstance(source, np.ndarray) else source.clone()
    outputs = {}
    for name in helpers:
        bridge._numpy_to_tensor = helpers[name]
        outputs[name] = call()
        for _ in range(20):
            call()
    np.testing.assert_array_equal(outputs["baseline"].numpy(), outputs["candidate"].numpy())
    if metadata["route"] == "bridge":
        assert np.shares_memory(source, outputs["baseline"].numpy())
        assert np.shares_memory(source, outputs["candidate"].numpy()) == (metadata["storage"] == "writable")
    bridge._numpy_to_tensor = candidate_helper
    duration = elapsed(call, 10)
    count = max(100, min(10000, int(10_000_000 / duration)))
    initial = paired(call, count, 5)
    result = {**metadata, "iterations_per_round": count, "initial": initial}
    if initial["change_percent"] > 5:
        result["investigation"] = paired(call, count, 11)
    np.testing.assert_array_equal(np.asarray(source), np.asarray(before_source))
    report["results"].append(result)
    if index % 10 == 0:
        print(f"Measured {index}/{len(rows)} cells", flush=True)
    args.output.write_text(json.dumps(report, indent=2, default=str) + "\n")
gc.enable()
report["environment"]["load_end"] = os.getloadavg()
args.output.write_text(json.dumps(report, indent=2, default=str) + "\n")
print(f"Complete: {len(rows)} cells, {args.output}", flush=True)
