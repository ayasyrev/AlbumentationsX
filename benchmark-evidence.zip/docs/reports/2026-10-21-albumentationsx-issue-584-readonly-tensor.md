# #584: локальный фикс readonly NumPy → Tensor

Подготовлен 21 октября 2026 по [плану](../plans/2026-10-21-albumentationsx-issue-584-readonly-tensor.md).
Источник требований: [issue #584](https://github.com/albumentations-team/AlbumentationsX/issues/584)
и прямое указание пользователя реализовать приведённый минимальный вариант.
Использован simple route; формальные task/plan reviews не применяются.

## Результат и точная ревизия

- Worktree: `/home/albu/Prj/Albu_Base/worktree/issue-584-readonly-tensor`.
- Branch: `aya/issue-584-readonly-tensor`.
- Base: `45a1afe21448fd2e83716733e2880c00335060fb`, свежая `upstream/main`.
- Commit: `ff6db7b86e9094112a2e5a0ba2268ab4f199791f`
  (`fix: copy readonly NumPy storage before Tensor fallback (#584)`).
- Четыре package-файла: две runtime-строки в `core/tensor.py`, регрессии
  bridge/Compose и уточнение storage contract в design document.
- Issue остаётся OPEN; исправление подготовлено локально. Push/PR/комментарии
  на GitHub не выполнялись. После реализации пользователь передал
  [независимое review без блокирующих замечаний](2026-10-21-albumentationsx-issue-584-review-handoff.md).

`_numpy_to_tensor` теперь делает `np.array(value, copy=True, order="C")`, если
массив readonly или имеет хотя бы один отрицательный stride. Для совместимой
writable памяти остаётся `torch.from_numpy` без копии. Существующая перестановка
осей выполняется до этого условия; dtype, значения и канонические оси сохранены.
Принудительная копия исправляет также C-contiguous массивы с отрицательным
stride singleton-оси, которые прежний `ascontiguousarray` оставлял без изменения.

## Correctness и quality gate

Точные команды, exits и промежуточные результаты:
[validation.json](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/validation.json).

| Проверка | Результат | Exit |
| --- | --- | --- |
| 460 новых cases на неизменённом baseline helper, после исправления тестового аргумента | **201 failed / 259 passed** | 1, ожидаемый red baseline |
| Полные `test_tensor_bridge.py` + `test_tensor_compose.py` с фиксом | **576 passed** | 0 |
| Tensor cases generated target cluster, reentrancy, tracing и annotation modules | **1 526 passed** | 0 |
| Финальный `pre-commit run --all-files --show-diff-on-failure` | Все hooks passed, включая AX rules, mypy и Pyrefly | 0 |
| Локальный commit со штатными hooks | Все применимые hooks passed | 0 |
| Парный performance harness | **120 cells**, все value/ownership проверки прошли | 0 |

Всего focused/adjacent pytest: **2 102 passed**. Новый helper module содержит
432 spatial storage cases, 12 annotation cases и 8 empty cases. Они проверяют
восемь пространственных targets, C1/C3, image helper uint8/float16/float32,
mask uint8/int16/float32, writable C/F/positive/zero strides, bytes-backed
readonly storage, readonly views/broadcasts и negative strides. Int16 masks
содержат отрицательные значения, поэтому тесты также обнаружат случайный clipping.
Annotation wrapper проверен для bboxes/keypoints, float32/float64 и ownership.

Независимый oracle — явные NumPy transpose axes и точные значения. Sharing
проверяется до записи, поэтому red baseline не пишет через Tensor в immutable
bytes. После безопасной записи проверяется сохранность отделённого source либо
ожидаемая видимость записи на writable zero-copy пути. Warnings перехватываются
явно, независимо от suite-wide ignore UserWarning.

Compose coverage включает пользовательский readonly callback, additional target,
uint8/float32 и настоящий RandomGamma для image/images/volume/volumes. Тест
RandomGamma использует значения 0/255, неизменные при фиксированной gamma=2,
проверяет storage до записи и сохранность input после неё. Существующие Tensor
tests дополнительно проверяют dtype/rank rejection, identity/skip, annotations,
native/fallback routing, replay, tracing и reentrancy.

Промежуточные failures сохранены: в первом варианте нового RandomGamma test
использовалось устаревшее имя `gamma_limit`. Оно заменено на актуальное
`gamma_range`; red baseline и candidate перезапущены с одинаковыми тестами.
Первый all-files gate вернул exit 1 только из-за автоудаления Ruff одной пустой
строки; повторный полный gate завершился exit 0.

Полный pytest suite, DataLoader multiprocessing, hosted CI и другие OS/Python
не запускались: dispatch/seed/IPC/dependencies не менялись, а затронутые Tensor
маршруты покрыты focused и generated contract tests. Результаты прошлой сессии
на #588 не выдаются за проверку этого commit.

## Performance: стоимость выбранной C-order копии

[Все 120 before/after cells](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark-cells.md),
[CSV](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark-cells.csv),
[raw samples/environment](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark.json),
[воспроизводимый harness](2026-10-21-albumentationsx-issue-584-readonly-tensor-evidence/benchmark.py).

Baseline установлен из точного Git archive в `/tmp/albu-584-baseline-installed`;
запуск выполнен вне checkout. Import path проверен. В одном процессе чередуются
исходный helper и helper, загруженный из финального candidate source, внутри
одинакового полного Compose pipeline. Других runtime-изменений в commit нет.
SHA-256 обоих source files сохранены; candidate соответствует указанному commit.

Linux x86-64, Ryzen 7 5800X, Python 3.13.14, NumPy 2.5.1, Torch 2.14.1+cpu,
OpenCV 5.0.0, published Albucore **0.2.21** из неизменённого main lockfile.
Core импортирован из собственного worktree `.venv`, local-core marker отсутствует.
Никакого переноса dependency upgrade из #588 нет. NumKong сообщает Haswell
capability, соответствующую хосту. Numerical env vars равны 1, Torch intra/inter-op
равны 1, OpenCV parallelism отключён (`setNumThreads(0)`, reported threads=1).
На хосте оставалась фоновая работа; load average и параметры сохранены. Это
локальные парные измерения, не универсальная гарантия времени на всех машинах.

Матрица image: 256/512/1024 × C1/C3/C5; bridge uint8/float16/float32,
Compose uint8/float32. Float16 image Tensor не входит в публичный Compose contract.
Дополнительно images N=4/8/16, сравнение с per-image Compose+stack, volume D=4
и volumes N=2,D=4 на 64×64/C1,C3. Direct bridge измерен на writable и readonly
storage. 20 warmups на вариант, минимум 100 calls на timed block, 5 парных
раундов; все **53** cells с первым результатом >+5% перепроверены 11 раундами
с чередованием порядка в том же процессе.

| Route | Наблюдение после перепроверок |
| --- | --- |
| Writable bridge | **+1,59…3,29%**, примерно **+0,05…0,09 µs**; zero-copy сохранён |
| Readonly bridge | Дополнительная полная копия: **+0,67 µs…2,39 ms**, в зависимости от размера/dtype; прежний baseline небезопасен |
| Compose RandomGamma uint8 | До **+26,69%**: 1024²/C5, **4,737 → 6,002 ms**; median по 16 image/batch/volume cells **+15,56%** |
| Compose RandomGamma float32 | **−1,26…+1,06%**, median **−0,03%**; значимого замедления в этой матрице нет |
| Per-image Compose+stack uint8 | **−9,58…−7,70%**; это отдельный measured route, не компенсация замедления batch path |

Рост readonly/uint8 времени — измеренный tradeoff выбранной C-order реализации
согласованного минимального исправления. Он не скрыт за средним ускорением и не объявлен
performance improvement. По коду добавляется один C-buffer размером массива
только в несовместимой ветке; `benchmark.json` содержит его размер для direct
cases. Peak RSS отдельно не измерялся.

Позднейшее независимое review выявило перспективный `order="K"` вариант:
по переданному пользователем отчёту, 452 bridge cases прошли, а в одном
1024²/C5 uint8 RandomGamma сравнении overhead снизился с 26,9% до 4,1%.
Это предварительный single-case результат; полная K-order matrix не проверена.
C-order дополнительно перепаковывает каналы после смены осей, поэтому +26,69%
не является доказанной неизбежной стоимостью безопасного копирования.

Optimization pass: подходящие views и conversions сохранены; лишняя полная
копия на общем входе Compose не вводится. Векторизация pixel loops, grouped
reductions/bincount, LUT, RNG и смена backend здесь не применимы — исправляется
storage wrap, а не image kernel. In-place запись в readonly source неприемлема.
`ascontiguousarray`/`np.require(C,W)` отвергнуты по контракту singleton strides;
безусловная копия теряет writable zero-copy. `.copy(C)` и `.copy(K)` отдельно
не измерялись на этапе реализации; отдельный K-order probe из последующего
review описан выше. Общий поддерживаемый Core bridge API остаётся будущей задачей;
новый helper и dependency API в этом фиксе не добавлялись.

## Review и передача

Выполнен собственный focused diff review по correctness/ownership, performance
и delivery. Производственный diff в точности соответствует принятому guard.
Live `upstream/main` повторно проверен перед commit: база не изменилась.
Package worktree после commit чистый; primary checkout и посторонние WIP сохранены.
Shared plan/report/evidence находятся в coordination workspace и не включены
в package commit.

Получено [issue-based review без блокеров](2026-10-21-albumentationsx-issue-584-review-handoff.md)
для **#584 + commit `ff6db7b86e9094112a2e5a0ba2268ab4f199791f`**.
Подготовлено [локальное описание PR](2026-10-21-albumentationsx-issue-584-pr-body.md);
публикация остаётся следующим этапом. Опциональный K-order вариант не внесён.
ToTensorV2/3D продолжают использовать собственный путь; foreign-endian
dtype требует отдельной конверсии в #595. Этот фикс не объявляет их исправленными.

Дополнение по запросу пользователя: [расширенная C/K-проверка](2026-10-21-albumentationsx-issue-584-order-k.md)
завершена на 671 timing cell и 2 102 существующих тестах с K. Универсальный K
не принят из-за измеренных регрессий и layout-sensitive ошибки зависимости.
Исходные результаты этого отчёта и C-order commit не менялись.
