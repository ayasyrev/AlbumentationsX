# NumKong uint8 moments evidence

See the [investigation report](../2026-10-21-numkong-strided-moments.md) and
[issue draft](../2026-10-21-numkong-strided-moments-issue.md).

## Files

- `reproduce.py`: self-contained minimal NumPy/NumKong reproducer and serial controls.
- `probes.py`: 114 cases per mode, Python-integer/uint64 independent expected values,
  input hashes, import paths, native module hashes, CPU and capability metadata.
- `numkong-7.8.4.json`, `numkong-7.8.5.json`: complete observations; both commands
  exit 1 because 39 automatic-backend results are wrong. All serial results pass.
- `excluded-cells.json`, `replay_exclusions.py`, `excluded-cells-serial.json`:
  repeat the two prior public failures with only Haswell disabled, 2 pass, exit 0.
- `audit_normalization.py`, `normalization-oracle-audit.json`: 36 prior Normalize
  cases checked against float64 statistics, including the two exclusions;
  all 34 timed cases pass NumPy/C/K independently. Exit 0 asserts no timed failure.
- `timing-exclusion-audit.json`: audit of the prior 671 timing cells and the
  exclusion/selection boundary. Original source hashes and data hashes retained.
- `validation.json`: final cross-artifact checks and unchanged prior evidence.

The broad probes and minimal reproduction are independent of Albumentations,
Albucore and Torch. The two integration scripts reuse the archived #584 harness
from the sibling `2026-10-21-albumentationsx-issue-584-order-k-evidence` directory,
the unchanged reviewed worktree, and the installed baseline in `/tmp`.

## Commands actually run

Resource preflight: `uptime`, `free -h`, `ps -eo pid,pcpu,pmem,comm --sort=-pcpu`.
Load was 0.10–0.94 per 16 logical CPUs; available memory about 90–91 GiB.

```bash
task_root=/home/albu/Prj/Albu_Base
task_tree="$task_root/worktree/issue-584-readonly-tensor"
task_evidence="$task_root/docs/reports/2026-10-21-numkong-strided-moments-evidence"
export UV_CACHE_DIR=/tmp/albu-584-uv-cache
cd /tmp
uv run --project "$task_tree" --no-sync python "$task_evidence/probes.py" "$task_evidence/numkong-7.8.4.json"
```

This completed with exit 1 (39 arithmetic failures), without changing project
dependencies. Fresh current-release environment setup:

```bash
UV_CACHE_DIR=/tmp/numkong-584-uv-cache uv venv --python "$task_tree/.venv/bin/python" /tmp/numkong-584-latest-env
UV_CACHE_DIR=/tmp/numkong-584-uv-cache uv pip install --python /tmp/numkong-584-latest-env/bin/python numpy==2.5.1 numkong==7.8.5
```

Setup eventually completed, exit 0; uv built NumKong 7.8.5 from source in 2m15s.
The first setup attempt lacked a writable uv cache, then a sandbox network
attempt failed DNS resolution. The successful install used the temporary cache
and network escalation. An early import check before installation completed
failed `ModuleNotFoundError`; only completed-environment runs are validation.

```bash
UV_CACHE_DIR=/tmp/numkong-584-uv-cache uv run --no-project --python /tmp/numkong-584-latest-env/bin/python python "$task_evidence/probes.py" "$task_evidence/numkong-7.8.5.json"
UV_CACHE_DIR=/tmp/numkong-584-uv-cache uv run --no-project --python /tmp/numkong-584-latest-env/bin/python python "$task_evidence/reproduce.py"
```

Probes exit 1 (same 39 failures); minimal reproduction exits 0 after printing the
incorrect automatic outputs and asserting correct serial controls.

Integration checks used these environment settings:

```bash
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
uv run --project "$task_tree" --no-sync python "$task_evidence/replay_exclusions.py"
uv run --project "$task_tree" --no-sync python "$task_evidence/audit_normalization.py"
```

Both completed with exit 0. No timing loops run in these checks. The serial
switch is local to the replay process and is not an application workaround or
dependency configuration change.

Upstream source provenance, latest-version query and duplicate search are in
the [primary-source report](../2026-10-21-numkong-strided-moments-sources.md).
