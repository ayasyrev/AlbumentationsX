"""Check every prior per-channel Normalize case against float64 statistics."""

import hashlib
import json
import sys
from pathlib import Path

evidence = Path(__file__).resolve().parent
workspace = evidence.parents[2]
original = evidence.parent / "2026-10-21-albumentationsx-issue-584-order-k-evidence/benchmark.py"
sys.argv = [str(original), "--baseline", "/tmp/albu-584-baseline-installed",
            "--candidate", str(workspace / "worktree/issue-584-readonly-tensor/albumentations/core/tensor.py"),
            "--phase", "preflight", "--output", str(evidence / "unused-setup.json")]
namespace = {"__file__": str(original), "__name__": "normalization_audit"}
source_text = original.read_text()
exec(compile(source_text[:source_text.index("\ngc.disable()")], str(original), "exec"), namespace)
A, np, bridge = (namespace[name] for name in ("A", "np", "bridge"))
timed_ids = set(json.loads((original.parent / "validated-cells.json").read_text()))
rows = [row for row in namespace["manifest"]() if row["transform"] in ("normalize", "gamma+normalize")]
report = {"oracle": "float64 NumPy per-channel mean/std, eps=1e-4, clip to [-20,20]",
          "harness_sha256": hashlib.sha256(source_text.encode()).hexdigest(),
          "source_hashes": namespace["report"]["hashes"],
          "environment": namespace["report"]["environment"], "results": []}
for row in rows:
    tensor_input = namespace["make_input"](row)
    numpy_input = bridge.tensor_to_numpy_spatial(tensor_input, "image").copy()
    values = numpy_input
    if row["transform"] == "gamma+normalize":
        spec = row["transforms"][0]
        values = A.Compose([getattr(A, spec["class"])(**spec["kwargs"])], seed=137, strict=True)(image=values)["image"]
    as_float = values.astype(np.float64)
    expected = np.clip((as_float - as_float.mean(axis=(0, 1))) /
                       (as_float.std(axis=(0, 1)) + 1e-4), -20, 20)
    results = {}
    for variant in ("NumPy", "C", "K"):
        pipeline = namespace["make_pipeline"](row)
        if variant == "NumPy":
            actual = pipeline(image=numpy_input)["image"]
        else:
            bridge._numpy_to_tensor = namespace["helpers"][variant]
            actual = bridge.tensor_to_numpy_spatial(pipeline(image=tensor_input)["image"], "image")
        results[variant] = {"correct": bool(np.allclose(actual, expected, rtol=2e-5, atol=2e-5)),
                            "max_error": float(np.max(np.abs(actual - expected)))}
    report["results"].append({"id": row["id"], "shape": row["shape"], "dtype": row["dtype"],
                              "transform": row["transform"], "included_in_timings": row["id"] in timed_ids,
                              "variants": results})
report["summary"] = {"cells": len(rows), "timed_cells": sum(row["included_in_timings"] for row in report["results"]),
                     "variant_checks": len(rows) * 3,
                     "wrong_results": sum(not outcome["correct"] for row in report["results"]
                                          for outcome in row["variants"].values()),
                     "timed_wrong_results": sum(row["included_in_timings"] and not outcome["correct"]
                                                for row in report["results"] for outcome in row["variants"].values())}
(evidence / "normalization-oracle-audit.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report["summary"]))
for row in report["results"]:
    if any(not outcome["correct"] for outcome in row["variants"].values()):
        print(row)
assert report["summary"]["timed_wrong_results"] == 0
