"""Standalone NumKong correctness probes; no Albumentations, Albucore or Torch."""

import hashlib
import importlib.metadata
import json
import os
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numkong as nk
import numpy as np


def digest(value):
    return hashlib.sha256(value.tobytes(order="C")).hexdigest()


def observe(value, expected, label, mode):
    before = digest(value)
    actual = tuple(int(item) for item in nk.moments(value))
    unchanged = digest(value) == before
    assert unchanged, label
    return {
        "label": label,
        "mode": mode,
        "dtype": str(value.dtype),
        "shape": value.shape,
        "strides": value.strides,
        "c_contiguous": value.flags.c_contiguous,
        "size": value.size,
        "input_sha256": before,
        "input_unchanged": unchanged,
        "expected": expected,
        "actual": actual,
        "correct": actual == tuple(expected),
        "sumsq_deficit": expected[1] - actual[1],
    }


def constants(mode):
    # Source-guided last passing lengths, followed by the first failing length.
    boundaries = {1: 528401, 2: 528416, 3: 363286, 4: 264208,
                  5: 231182, 6: 396312, 7: 330260, 8: 132104}
    manifest = set()
    for stride, last_good in boundaries.items():
        for count in (last_good - 1, last_good, last_good + 1, last_good + 2):
            manifest.add((count, stride, 255))
    for stride in (1, 4, 5, 8, 9, 16):
        for count in (0, 1, 31, 32, 33, 300000, 1000000, 2097152, 2097153):
            manifest.add((count, stride, 255))
    for stride in (1, 4, 5, 8):
        for fill in (0, 1, 127, 254):
            manifest.add((300000, stride, fill))
    for count, stride, fill in sorted(manifest):
        source = np.full(count * stride, fill, dtype=np.uint8)
        value = source[::stride]
        expected = (count * fill, count * fill * fill)  # Python integers, no dtype overflow.
        yield observe(value, expected, f"constant-{fill}-n{count}-stride{stride}", mode)
    for stride in (1, 3, 4, 5, 8, 9):
        value = np.full((600, 500, stride), 255, dtype=np.uint8)[..., 0]
        yield observe(value, (300000 * 255, 300000 * 65025), f"rank2-stride{stride}", mode)


def originals(mode):
    for channels in (4, 5):
        original = (np.random.default_rng(137).uniform(0.1, 0.9, (1024, 1024, channels)).astype(np.float32)
                    * 255).astype(np.uint8)
        expected = (int(original[..., 0].sum(dtype=np.uint64)),
                    int(np.square(original[..., 0].astype(np.uint64)).sum(dtype=np.uint64)))
        for layout, value in (
            ("interleaved", original[..., 0]),
            ("planar", original.transpose(2, 0, 1).copy().transpose(1, 2, 0)[..., 0]),
            ("flat", original[..., 0].copy().reshape(-1)),
        ):
            yield observe(value, expected, f"original-C{channels}-{layout}", mode)


cpu_lines = Path("/proc/cpuinfo").read_text().splitlines()
caps = nk.get_capabilities()
report = {
    "started_utc": datetime.now(timezone.utc).isoformat(),
    "python": sys.version,
    "executable": sys.executable,
    "platform": platform.platform(),
    "cpu": next(line.split(":", 1)[1].strip() for line in cpu_lines if line.startswith("model name")),
    "numkong": importlib.metadata.version("numkong"),
    "numpy": np.__version__,
    "numkong_module": nk.__file__,
    "numpy_module": np.__file__,
    "capabilities_initial": caps,
    "load_start": os.getloadavg(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "native_modules": {
        name: {"path": module.__file__, "sha256": hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()}
        for name, module in sys.modules.items()
        if name.startswith("numkong") and getattr(module, "__file__", "").endswith(".so")
    },
    "cases": [],
}
for mode in ("automatic", "serial"):
    if mode == "serial":
        for capability, enabled in caps.items():
            if enabled and capability != "serial":
                nk.disable_capability(capability)
    report[f"capabilities_{mode}"] = nk.get_capabilities()
    report["cases"].extend(constants(mode))
    report["cases"].extend(originals(mode))
    rows = [row for row in report["cases"] if row["mode"] == mode]
    failures = sum(not row["correct"] for row in rows)
    print(f"NumKong {report['numkong']} {mode}: {len(rows)} cases, {failures} wrong results", flush=True)
for capability, enabled in caps.items():
    if enabled and capability != "serial":
        nk.enable_capability(capability)
report["capabilities_restored"] = nk.get_capabilities()
report["load_end"] = os.getloadavg()
report["summary"] = {
    mode: {"cases": sum(row["mode"] == mode for row in report["cases"]),
           "wrong_results": sum(row["mode"] == mode and not row["correct"] for row in report["cases"])}
    for mode in ("automatic", "serial")
}
Path(sys.argv[1]).write_text(json.dumps(report, indent=2) + "\n")
raise SystemExit(any(not row["correct"] for row in report["cases"]))
