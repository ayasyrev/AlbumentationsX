"""Replay the two prior semantic failures with NumKong's Haswell path disabled."""

import runpy
import sys
from pathlib import Path

import numkong as nk

evidence = Path(__file__).resolve().parent
workspace = evidence.parents[2]
original = evidence.parent / "2026-10-21-albumentationsx-issue-584-order-k-evidence/benchmark.py"
nk.disable_capability("haswell")
print("NumKong capabilities for replay:", {name: enabled for name, enabled in nk.get_capabilities().items() if enabled})
sys.argv = [
    str(original),
    "--baseline", "/tmp/albu-584-baseline-installed",
    "--candidate", str(workspace / "worktree/issue-584-readonly-tensor/albumentations/core/tensor.py"),
    "--phase", "preflight",
    "--select", str(evidence / "excluded-cells.json"),
    "--output", str(evidence / "excluded-cells-serial.json"),
]
runpy.run_path(str(original), run_name="__main__")
