"""Minimal uint8 moments reproducer: NumPy and NumKong only."""

from importlib.metadata import version

import numkong as nk
import numpy as np

print("NumKong", version("numkong"), "NumPy", np.__version__)
print("Capabilities:", {name: enabled for name, enabled in nk.get_capabilities().items() if enabled})
strided = np.full(1_200_000, 255, dtype=np.uint8)[::4]
contiguous = np.full(1_000_000, 255, dtype=np.uint8)
for name, value in (("strided", strided), ("strided.copy()", strided.copy()), ("contiguous", contiguous)):
    expected = (value.size * 255, value.size * 255**2)
    print(name, "actual:", nk.moments(value), "expected:", expected)
nk.disable_capability("haswell")
print("After disabling Haswell:")
for name, value in (("strided", strided), ("contiguous", contiguous)):
    expected = (value.size * 255, value.size * 255**2)
    actual = nk.moments(value)
    print(name, "actual:", actual, "expected:", expected)
    assert actual == expected
