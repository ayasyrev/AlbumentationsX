# NumKong uint8 moments: primary-source investigation

Research date: 2026-10-21. Scope: public contract, current upstream source,
release freshness, and duplicate search. Runtime reproductions are recorded by
the parent investigation; this source-reading task ran no tests or benchmarks
and changed no package or upstream code.

## Finding

The supported NumKong `uint8` moments path contains a concrete overflow defect
in the Haswell backend. Both contiguous and short-stride kernels accumulate
and merge squared values in 32-bit lanes before widening to the documented
64-bit result. Their recursive split limit allows inputs long enough to
overflow those lanes. This is upstream arithmetic, independent of
Albumentations or Albucore; array layout changes when the problem appears,
but a contiguous copy is not a general remedy. This conclusion follows from
the [contiguous and strided kernels](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce/haswell.h#L1141-L1231)
and the [64-bit output contract](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce.h#L145-L155).

## Supported input and output contract

- The public Python docstring accepts a NumPy array, NumKong Tensor, or another
  buffer-protocol object and promises the sum and sum of squares over all
  elements. The NumPy-buffer path parses an N-D view directly. There is no
  stated contiguous-only or maximum-length restriction at this boundary.
  [Python binding, lines 3188–3230](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/python/tensor.c#L3188-L3230).
- The C reduction explicitly takes an element count and a byte stride. Both
  outputs of its `uint8` specialization are `uint64`. The type-selection
  functions also select `uint64` for both outputs when input is `uint8`.
  [C contract](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce.h#L112-L155),
  [output type selection](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce.h#L863-L919).
- An existing upstream test deliberately passes a `uint8` HWC channel view
  `base[:, :, 1]` to `nk.moments`. This is the same category of input used by
  Albucore. The test uses only a 64×64×3 base with values below 100, and compares
  against another NumKong call on a contiguous copy; it is not an independent
  large-input arithmetic oracle.
  [N-D helper and channel-view test](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/test/test_reduce.py#L668-L737).
- N-D uniformly strided dimensions collapse into one kernel invocation. Thus
  a 1024×1024 channel view with byte strides `(4096, 4)` becomes a reduction of
  1,048,576 elements with byte stride 4. It is not reduced in independent
  1024-element rows. This explains why a valid 2-D view reaches the same
  length-dependent defect as a 1-D strided view.
  [N-D collapse and moments traversal](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/python/tensor.c#L1243-L1291).

The Python stub says `tuple[float, float]`, but the implementation converts
the selected typed scalar buffers to Python numbers. For the integer inputs
under investigation the C arithmetic contract, rather than the imprecise stub,
is the relevant evidence.
[Result conversion](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/python/tensor.c#L1476-L1491),
[stub](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/python/numkong/__init__.pyi#L801-L803).

## Mechanism and bounded scope

The Haswell `uint8` dispatcher chooses `nk_reduce_moments_u8_haswell` when
that capability is available. The selected backend should still be confirmed
with runtime capability controls on the reproducing machine; source selection
alone does not identify a wheel's active backend.
[Dispatcher](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/c/dispatch_u8.c#L211-L223).

In the contiguous kernel, `_mm256_madd_epi16` forms pairwise squared sums.
The loop accumulates these into two vectors of eight 32-bit lanes. At line
1169 those vectors are added in 32 bits, then widened without recovering
discarded carries. With all input values equal to 255, each final lane receives
four squared values per 32 input bytes. After 16,512 complete vectors, a final
18-byte tail makes the first merged lane exceed `2**32 - 1`; the corresponding
input count is 528,402. This is a source-derived boundary for this exact input,
not a universal boundary for arbitrary values.
[Contiguous kernel](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce/haswell.h#L1141-L1173).

The strided path masks unused bytes but uses the same 32-bit accumulation and
merge. At byte stride 4, four final lanes receive two squared values per eight
logical input elements. For constant 255, its loop/tail condition first allows
the overflowing 33,026th SIMD iteration at 264,209 logical elements. The final
64-bit tail computation cannot restore the carries already lost by the SIMD
merge. Different strides alter lane occupancy and therefore the threshold.
[Strided kernel](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce/haswell.h#L1176-L1208).

The common wrapper splits only when `count > (65535 + 1) * 32`, or 2,097,152
elements. This limit is too late for the examples above. Its saturating addition
of already-computed 64-bit subresults does not protect internal 32-bit lanes.
Strides greater than 8 select the serial implementation, which widens each input
value before squaring; its arithmetic is a useful control for these sizes.
[Wrapper](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce/haswell.h#L1211-L1231),
[serial implementation](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/include/numkong/reduce/serial.h#L111-L121).

This report establishes the Haswell `uint8` defect. Other integer types and
other SIMD backends were not audited or executed here. The final sums used in
the reproductions are far below the 64-bit range, so this is not expected
saturation of the public result.

## Release freshness and source identity

Live PyPI JSON reported **7.8.5** as the latest release, with sdist upload time
`2026-10-05T21:41:02.132446Z`. GitHub `main` and tag `v7.8.5` both resolve to
`337c1cb6e6fbea8c08b3b7b385e392ed95ccab46`; tag `v7.8.4` resolves to
`d3c21404b995b9b7e125bbcfc0374606ca09aac4`.
[PyPI metadata](https://pypi.org/pypi/numkong/json),
[v7.8.5 source](https://github.com/ashvardanian/NumKong/tree/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46),
[v7.8.4 source](https://github.com/ashvardanian/NumKong/tree/d3c21404b995b9b7e125bbcfc0374606ca09aac4).

The complete `v7.8.4...main` comparison contains the Windows shared-library
consumption fix and the release commit. It does not change the moments kernels,
Python tensor binding, reduction tests, or `uint8` dispatcher examined above.
The source defect therefore remains present on current main; execution against
the 7.8.5 wheel is a separate validation step.
[Full release comparison](https://github.com/ashvardanian/NumKong/compare/v7.8.4...337c1cb6e6fbea8c08b3b7b385e392ed95ccab46).

Downloaded official sdist:

- `/tmp/numkong-7.8.5.tar.gz`, unpacked at `/tmp/numkong-7.8.5`.
- Archive SHA-256: `fc7e5353a61e1d87018c9026581000af606532a8dba0e470c13d0ed95ffec3d6`.
- `include/numkong/reduce/haswell.h`: `9251d7aa6f3f036844f34ab74ff06483166d34fc0ae363b84a08b2e774c0af36`.
- `python/tensor.c`: `381cb562bd47332dd0abd16baca66b416dd0aef7924a1a463be57ddee7dab126`.

The downloaded archive hash matches the SHA-256 advertised by the live
[PyPI metadata](https://pypi.org/pypi/numkong/json).

## Duplicate search and issue preparation

GitHub issue/PR search was performed on 2026-10-21 with these exact queries:

```text
repo:ashvardanian/NumKong moments
repo:ashvardanian/NumKong uint8
repo:ashvardanian/NumKong overflow
repo:ashvardanian/NumKong strided
repo:ashvardanian/NumKong sumsq
repo:ashvardanian/NumKong haswell moments
```

No matching open or closed `uint8` Haswell moments report was found in these
search results. This is a bounded search result, not a guarantee that no
duplicate exists. Related results were checked:

- [#399](https://github.com/ashvardanian/NumKong/issues/399) and
  [PR #400](https://github.com/ashvardanian/NumKong/pull/400) concern `float16`
  subnormal accuracy on NEON-half, a different dtype and backend.
- [#336](https://github.com/ashvardanian/NumKong/issues/336) is the closed N-D
  moments traversal performance issue, not this arithmetic failure.
- [#311](https://github.com/ashvardanian/NumKong/issues/311) requests axis-aware
  combined reductions and explicitly describes Albucore's existing channel-view
  calls; it does not report this overflow.
- [PR #388](https://github.com/ashvardanian/NumKong/pull/388), merged September 24,
  2026, changed floating-point compensation in the Haswell reduction file. Its
  patch does not change the `uint8` path examined here.

A distinct upstream bug report is appropriate once the parent investigation
records its standalone reproduction and current-release execution. The issue
should include both contiguous and strided examples so it does not imply that
copying to contiguous storage generally fixes the defect. A NumPy-plus-NumKong
reproducer is sufficient; Albucore/Albumentations are downstream impact context.

The current [bug report template](https://github.com/ashvardanian/NumKong/blob/337c1cb6e6fbea8c08b3b7b385e392ed95ccab46/.github/ISSUE_TEMPLATE/bug_report.yml)
requires bug description, steps, expected behavior, version, OS, architecture,
interface, duplicate-search confirmation, and Code of Conduct agreement.
Contact details and contributor-credit opt-in are optional. No issue was posted
and no external comment was sent during this task.
